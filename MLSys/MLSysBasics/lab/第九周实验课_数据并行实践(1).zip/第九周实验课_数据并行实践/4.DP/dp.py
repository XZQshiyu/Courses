import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import torch.nn.functional as F

# 1. Define a simple neural network model
class SimpleNN(nn.Module):
    def __init__(self, input_size=10, hidden_size=20, output_size=2):
        super(SimpleNN, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.fc2 = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        return x

# 2. Generate synthetic data (for example purposes)
def generate_synthetic_data(num_samples=1000, input_size=10, output_size=2):
    X = torch.randn(num_samples, input_size)
    y = torch.randint(0, output_size, (num_samples,))
    return X, y

# 3. Main training function
def train_model(model, data_loader, criterion, optimizer, num_epochs=5):
    for epoch in range(num_epochs):
        for inputs, labels in data_loader:
            # Move data to device (GPU or CPU)
            inputs, labels = inputs.to(device), labels.to(device)
            
            # Forward pass
            outputs = model(inputs)
            loss = criterion(outputs, labels)

            # Backward and optimize
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        
        print(f"Epoch [{epoch+1}/{num_epochs}], Loss: {loss.item():.4f}")

# 4. Set up the Data Parallel model
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = SimpleNN()
# Wrapping the model in DataParallel if there are multiple GPUs available
model = nn.DataParallel(model)  # Automatically handles splitting the batch across GPUs
model = model.to(device)

# 5. Create synthetic dataset and DataLoader
input_size, output_size = 10, 2
X, y = generate_synthetic_data(input_size=input_size, output_size=output_size)
dataset = TensorDataset(X, y)
data_loader = DataLoader(dataset, batch_size=32, shuffle=True)

# 6. Define loss function and optimizer
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# 7. Train the model
train_model(model, data_loader, criterion, optimizer)

# 8. Save and evaluate the model (optional)
torch.save(model.state_dict(), "simple_nn_model.pth")
