Here's an instructional text that walks you through understanding and using the code to learn **Data Parallelism** in PyTorch.

------

# Data Parallelism in PyTorch: Tutorial

In this tutorial, you'll learn how to use **Data Parallelism** in PyTorch to leverage multiple GPUs when training a neural network. This is useful for accelerating training on large datasets or complex models, but the same code can still run on a single CPU or GPU for learning purposes.

## Overview

Data Parallelism involves splitting data across multiple devices (like GPUs), performing computations on each device in parallel, and then aggregating the results. PyTorch provides a built-in `torch.nn.DataParallel` module, which handles this process for us.

In this tutorial, we’ll:

1. Define a simple neural network model.
2. Create synthetic data for training.
3. Use PyTorch’s `DataParallel` to enable multi-GPU parallelism (or simulate it if you only have one device).
4. Train the model and observe the behavior.

Let’s go through the code step-by-step.

------

## Step 1: Define a Simple Model

The `SimpleNN` class represents a simple neural network with one hidden layer. We’ll use this basic model to focus on learning parallelism rather than model complexity.

```python
class SimpleNN(nn.Module):

def __init__(self, input_size=10, hidden_size=20, output_size=2):

super(SimpleNN, self).__init__()

self.fc1 = nn.Linear(input_size, hidden_size)

self.fc2 = nn.Linear(hidden_size, output_size)

def forward(self, x):

x = F.relu(self.fc1(x))

x = self.fc2(x)

return x
```

- **Explanation**: This model takes an input, passes it through a hidden layer with ReLU activation, and outputs predictions.

## Step 2: Generate Synthetic Data

We’ll generate random data to simulate a classification problem with two classes.

```python
def generate_synthetic_data(num_samples=1000, input_size=10, output_size=2):

X = torch.randn(num_samples, input_size)

y = torch.randint(0, output_size, (num_samples,))

return X, y
```

- **Explanation**: The `X` tensor holds random features, and `y` holds labels in two classes. This way, we can focus on training mechanics without worrying about real datasets.

## Step 3: Set Up Data Parallelism

To enable data parallelism, we’ll wrap our model in PyTorch’s `DataParallel` module. This module automatically splits your input batch across all available GPUs, performs parallel computations, and synchronizes results.

```python
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

model = SimpleNN()

model = nn.DataParallel(model)

model = model.to(device)
```

- **Explanation**: We check if GPUs are available and, if so, initialize our model to run on them. `DataParallel` will manage the distribution across GPUs automatically. If only a CPU is available, the model will train on it without issues.

## Step 4: Define the Training Function

This function, `train_model`, demonstrates a typical training loop. Data is moved to the appropriate device, and `DataParallel` handles synchronization across devices.

```python
def train_model(model, data_loader, criterion, optimizer, num_epochs=5):

for epoch in range(num_epochs):

for inputs, labels in data_loader:

inputs, labels = inputs.to(device), labels.to(device)

outputs = model(inputs)

loss = criterion(outputs, labels)

optimizer.zero_grad()

loss.backward()

optimizer.step()

print(f"Epoch [{epoch+1}/{num_epochs}], Loss: {loss.item():.4f}")
```

- **Explanation**: This function goes through each batch, moves it to the correct device, computes the forward pass, backpropagates the loss, and updates model weights.

## Step 5: Training

Let’s put it all together, create a `DataLoader`, and start training the model.

```python
# Generate data

input_size, output_size = 10, 2

X, y = generate_synthetic_data(input_size=input_size, output_size=output_size)

dataset = TensorDataset(X, y)

data_loader = DataLoader(dataset, batch_size=32, shuffle=True)

# Define loss and optimizer

criterion = nn.CrossEntropyLoss()

optimizer = optim.Adam(model.parameters(), lr=0.001)

# Train the model

train_model(model, data_loader, criterion, optimizer)
```

### Explanation:

- **DataLoader**: This utility batches data and shuffles it for each epoch.
- **Loss and Optimizer**: We use Cross-Entropy loss for classification and the Adam optimizer to update the model.

## Running the Code

- **Single Device**: If you only have one GPU or CPU, `DataParallel` will still work. You’ll see that training proceeds as usual, with no splitting of data.
- **Multi-GPU Setup**: If you run this code on a system with multiple GPUs, `DataParallel` will automatically split each batch across the GPUs and synchronize the gradients, allowing for faster training.

## Key Takeaways

- **Data Parallelism** in PyTorch makes it easy to split computation across GPUs by wrapping the model in `DataParallel`.
- **Scalability**: Even without multiple GPUs, you can learn the syntax and concepts.
- **Resource Utilization**: If you monitor your GPU’s utilization, you’ll see the model using all available devices if running on a multi-GPU system.

------

This tutorial provides a straightforward way to experiment with Data Parallelism in PyTorch, allowing you to understand how PyTorch handles distributed model training, even if you only have access to a single device.