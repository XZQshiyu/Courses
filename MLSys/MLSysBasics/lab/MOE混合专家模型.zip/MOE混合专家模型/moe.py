import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset
import numpy as np
import random

def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True

set_seed()

class Expert(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super(Expert, self).__init__()
        self.fc1 = nn.Linear(input_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        return x
    
class GatingNetwork(nn.Module):
    def __init__(self, input_dim, num_experts):
        super(GatingNetwork, self).__init__()
        self.fc = nn.Linear(input_dim, num_experts)

    def forward(self, x):
        # 计算专家选择概率
        gate_outputs = F.softmax(self.fc(x), dim=-1)
        return gate_outputs

class MoE(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim, num_experts):
        super(MoE, self).__init__()
        self.num_experts = num_experts
        self.experts = nn.ModuleList([Expert(input_dim, hidden_dim, output_dim) for _ in range(num_experts)])
        self.gating_network = GatingNetwork(input_dim, num_experts)

    def forward(self, x):
        # 获取门控网络输出的专家权重
        gate_outputs = self.gating_network(x)  # (batch_size, num_experts)
        
        # 获取每个专家的输出
        expert_outputs = torch.stack([expert(x) for expert in self.experts], dim=-1)  # (batch_size, output_dim, num_experts)
        
        # 根据门控输出的权重加权专家输出
        output = torch.sum(expert_outputs * gate_outputs.unsqueeze(1), dim=-1)  # (batch_size, output_dim)
        return output

def generate_data(num_samples=1000, input_dim=10):
    X = torch.randn(num_samples, input_dim)
    y = torch.sum(X, dim=1, keepdim=True) + torch.randn(num_samples, 1) * 0.1  # 加一些噪声
    return X, y

input_dim = 10
output_dim = 1
X, y = generate_data(num_samples=2000, input_dim=input_dim)
dataset = TensorDataset(X, y)
train_loader = DataLoader(dataset, batch_size=32, shuffle=True)

def train_moe_model(model, data_loader, epochs=20, lr=0.001):
    criterion = nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)

    for epoch in range(epochs):
        model.train()
        total_loss = 0
        for batch_X, batch_y in data_loader:
            optimizer.zero_grad()
            outputs = model(batch_X)
            loss = criterion(outputs, batch_y)
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
        
        print(f"Epoch {epoch + 1}/{epochs}, Loss: {total_loss / len(data_loader):.4f}")

# 初始化并训练 MoE 模型
hidden_dim = 16
num_experts = 4
model = MoE(input_dim, hidden_dim, output_dim, num_experts)
train_moe_model(model, train_loader)


def evaluate_model(model, X, y):
    model.eval()
    with torch.no_grad():
        predictions = model(X)
        mse = F.mse_loss(predictions, y)
    print(f"Test MSE: {mse:.4f}")

# 生成测试数据并评估模型
X_test, y_test = generate_data(num_samples=500, input_dim=input_dim)
evaluate_model(model, X_test, y_test)
