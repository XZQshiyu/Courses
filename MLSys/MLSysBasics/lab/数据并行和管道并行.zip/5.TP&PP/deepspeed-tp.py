import torch
import torch.nn as nn
import deepspeed
import argparse

# Model definition (same as above, but you can use a bigger model for TP)
class SimpleModel(nn.Module):
    def __init__(self):
        super(SimpleModel, self).__init__()
        self.fc = nn.Linear(128, 10)
    
    def forward(self, x):
        return self.fc(x)

deepspeed_config = {
  "train_batch_size": 8,
  "gradient_accumulation_steps": 1,
  "optimizer": {
    "type": "Adam",
    "params": {
      "lr": 0.00015
    }
  },
    "zero_optimization": {
        "stage": 0  # Optimized memory management (optional but useful)
    },
}

# Setup DeepSpeed
def train_deepspeed():
    # parser = argparse.ArgumentParser(description='My training script.')
    # parser.add_argument('--local_rank', type=int, default=-1,
    #                     help='local rank passed from distributed launcher')
    # # Include DeepSpeed configuration arguments
    # parser = deepspeed.add_config_arguments(parser)
    # cmd_args = parser.parse_args()
    
    model = SimpleModel()
    optimizer = torch.optim.SGD(model.parameters(), lr=0.01)

    model, optimizer, _, _ = deepspeed.initialize(
        model=model, optimizer=optimizer,
        config_params=deepspeed_config)

    # Dummy dataset
    X = torch.randn(1000, 128)
    y = torch.randint(0, 10, (1000,))
    
    for epoch in range(10):
        for i in range(0, len(X), 64):
            inputs = X[i:i+64]
            targets = y[i:i+64]
            inputs, targets = inputs.cuda(), targets.cuda()

            optimizer.zero_grad()
            output = model(inputs)
            loss = nn.CrossEntropyLoss()(output, targets)
            # print some metrics
            if i % 100 == 0:
                print(f'Epoch: {epoch}, Loss: {loss.item()}')
            model.backward(loss)
            model.step()

train_deepspeed()
