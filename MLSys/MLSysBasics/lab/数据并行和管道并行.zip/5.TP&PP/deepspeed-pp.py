# Example code for Pipeline Parallelism in PyTorch.

import torch
import torch.nn as nn
import deepspeed

# Define Segment 1 of the model
class Segment1(nn.Module):
    def __init__(self):
        super(Segment1, self).__init__()
        self.fc = nn.Linear(128, 256)  # Layer that transforms the input
        
    def forward(self, x):
        return self.fc(x)

# Define Segment 2 of the model
class Segment2(nn.Module):
    def __init__(self):
        super(Segment2, self).__init__()
        self.fc = nn.Linear(256, 10)  # Output layer for classification
        
    def forward(self, x):
        return self.fc(x)

# Create the full model using DeepSpeed's pipeline parallelism
class PipelineModel(nn.Module):
    def __init__(self):
        super(PipelineModel, self).__init__()
        self.segment1 = Segment1()
        self.segment2 = Segment2()

    def forward(self, x):
        # Forward pass across two segments in pipeline
        x = self.segment1(x)
        x = self.segment2(x)
        return x

# Create the model
model = PipelineModel()

import deepspeed
import torch.optim as optim

# Define optimizer
optimizer = optim.SGD(model.parameters(), lr=0.01)

# Define a dummy dataset
X = torch.randn(1000, 128)  # 1000 samples, 128 features
y = torch.randint(0, 10, (1000,))  # 1000 labels (for classification)
dataset = torch.utils.data.TensorDataset(X, y)
train_loader = torch.utils.data.DataLoader(dataset, batch_size=64, shuffle=True)

# Define DeepSpeed configuration for pipeline parallelism
deepspeed_config = {
    "train_batch_size": 64,
    "steps_per_print": 100,
    "zero_optimization": {
        "stage": 0  # Optimized memory management (optional but useful)
    },
    "pipeline": {
        "parallel_size": 2,  # Number of devices (GPUs) for pipeline parallelism
        "activation_checkpoint_interval": 1,  # How frequently to checkpoint activations for memory efficiency
        "activation_checkpoint_units": 2  # How many layers to group for activation checkpointing
    },
}

# Initialize the model with DeepSpeed
model, optimizer, _, _ = deepspeed.initialize(
    model=model,
    optimizer=optimizer,
    config=deepspeed_config
)

# Training loop
for epoch in range(10):
    for data, target in train_loader:
        data, target = data.cuda(), target.cuda()  # Move data to GPU

        optimizer.zero_grad()  # Zero gradients
        output = model(data)   # Forward pass
        loss = torch.nn.CrossEntropyLoss()(output, target)  # Compute loss
        model.backward(loss)   # Backward pass (via DeepSpeed)
        model.step()           # Optimizer step (via DeepSpeed)

    print(f"Epoch {epoch+1}: Loss {loss.item()}")
